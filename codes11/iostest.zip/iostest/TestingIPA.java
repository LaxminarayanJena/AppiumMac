package iostest;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSStartScreenRecordingOptions;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.screenrecording.BaseStartScreenRecordingOptions;
import io.appium.java_client.screenrecording.ScreenRecordingUploadOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class TestingIPA {

	public static IOSDriver<IOSElement> driver;
	
	
	public static void main(String[] args) throws MalformedURLException {
	
		
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		 //   capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION, "1.6.4");
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1.3");
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone X");
		
		   capabilities.setCapability("app", "/Users/rahularora/Library/Developer/Xcode/DerivedData/WebDriverAgent-brdadhpuduowllgivnnvuygpwhzy/Build/Products/Debug-iphoneos/IntegrationApp.app");
		   // capabilities.setCapability("app", "/Users/rahularora/Desktop/Care/Payload/Care.app");
		    
		   
		    capabilities.setCapability("udid","571e1c5acf8c4e0d47c6d146186d8749c8fab5b0");
		    
		    
		    	capabilities.setCapability("bundleId","com.facebook.wda.integrationApp");
		    
		    capabilities.setCapability("automationName", "XCUITest");

		    driver = new IOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		   
		    
		    //InteractsWithApps
		   System.out.println(driver.getDeviceTime());
		    driver.findElement(By.name("Alerts")).click();
	
		    System.out.println(driver.findElements(By.xpath("//XCUIElementTypeApplication/XCUIElementTypeWindow/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton")).size());
		
		   // driver.findElement(By.xpath("//XCUIElementTypeButton[@name='Alerts']")).click();
	
		    driver.findElement(MobileBy.AccessibilityId("Alerts")).click();
		    
		   //driver.lockDevice();
		    
		
		    
		    driver.quit();
		    
	}

	}


