package iostest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class SafariTestRealDevice {

	public static IOSDriver<MobileElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		/*
		 * Way2Automation.com
		 * 
		 * brew install ios-webkit-debug-proxy
		 * 
		 * ios_webkit_debug_proxy -c 571e1c5acf8c4e0d47c6d146186d8749c8fab5b0:27753
		 * 
		 * Troubleshooting if facing issues with ios-webkit-debug-proxy
		 * 
		 * 
		 * brew uninstall ios-webkit-debug-proxy 
		 * brew uninstall ideviceinstaller 
		 * brew uninstall libimobiledevice
		 * 
		 * brew install --HEAD libimobiledevice 
		 * brew install ideviceinstaller 
		 * brew install ios-webkit-debug-proxy 
		 * sudo chmod -R 777 /var/db/lockdown/
		 * 
		 * ios_webkit_debug_proxy -c 571e1c5acf8c4e0d47c6d146186d8749c8fab5b0:27753
		 * 
		 * 
		 * while installing libimobile device if you get lower version error for usbmuxd
		 * then follow below 2 steps:
		 * 
		 * brew unlink usbmuxd 
		 * brew install --HEAD usbmuxd
		 * 
		 * 
		 */

		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "safari");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1.3");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone X");

		capabilities.setCapability("udid", "571e1c5acf8c4e0d47c6d146186d8749c8fab5b0");

		capabilities.setCapability("automationName", "XCUITest");

		driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		driver.get("http://google.com");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.name("q")).sendKeys("Appium Tutorials by Way2Automation");

		Thread.sleep(5000);

		driver.quit();

	}

}
