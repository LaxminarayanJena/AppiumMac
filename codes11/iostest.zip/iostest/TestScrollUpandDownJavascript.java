package iostest;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSStartScreenRecordingOptions;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.screenrecording.BaseStartScreenRecordingOptions;
import io.appium.java_client.screenrecording.ScreenRecordingUploadOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class TestScrollUpandDownJavascript {

	public static IOSDriver<IOSElement> driver;
	
	public static void swipe(int x_start, int y_start, int x_stop, int y_stop, int duration) {
		new TouchAction(driver).press(PointOption.point(x_start, y_start)) .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(duration)))
		.moveTo(PointOption.point(x_stop, y_stop)) .release() .perform();
		}
	
	
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
	
		
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		 //   capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION, "1.6.4");
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1.3");
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone X");
		
		    capabilities.setCapability("xcodeOrgId", "LUBWEAQUT4");
		    capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		   capabilities.setCapability("app", "/Users/rahularora/Library/Developer/Xcode/DerivedData/WebDriverAgent-brdadhpuduowllgivnnvuygpwhzy/Build/Products/Debug-iphoneos/IntegrationApp.app");
	
		   
		    capabilities.setCapability("udid","571e1c5acf8c4e0d47c6d146186d8749c8fab5b0");
		    
		    
		    	capabilities.setCapability("bundleId","com.facebook.wda.integrationApp");
		    
		    capabilities.setCapability("automationName", "XCUITest");

		    driver = new IOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		   
		    

		 
		    driver.findElement(MobileBy.AccessibilityId("Scrolling")).click();
		    driver.findElement(MobileBy.AccessibilityId("TableView")).click();

		   
		    
		    System.out.println(driver.findElement(MobileBy.AccessibilityId("35")).isDisplayed());
		    
		 
		    
		 // scroll down then up
		    Map<String, Object> arg = new HashMap<String, Object>();
		   // arg.put("direction", "down");
		    //driver.executeScript("mobile: scroll", arg);
		    //arg.put("direction", "up");
		    //driver.executeScript("mobile: scroll", arg);

		    MobileElement list =  driver.findElement(By.className("XCUIElementTypeTable"));
		    // scroll to the last item in the list by accessibility id
		    arg.put("direction", "down");
		    arg.put("name", "35");
		    arg.put("element", list.getId());
		    driver.executeScript("mobile: scroll", arg);
		    
		    
		    
		    System.out.println(driver.findElement(MobileBy.AccessibilityId("35")).isDisplayed());
		    
		
		    System.out.println(driver.findElement(MobileBy.AccessibilityId("1")).isDisplayed());
		    
		    driver.quit();
		    
	}

	}


