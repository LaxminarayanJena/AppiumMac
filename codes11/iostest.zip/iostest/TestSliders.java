package iostest;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSStartScreenRecordingOptions;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.screenrecording.BaseStartScreenRecordingOptions;
import io.appium.java_client.screenrecording.ScreenRecordingUploadOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class TestSliders {

	public static IOSDriver<IOSElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1.3");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone X");

		capabilities.setCapability("xcodeOrgId", "LUBWEAQUT4");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		capabilities.setCapability("app",
				"/Users/rahularora/Library/Developer/Xcode/DerivedData/WebDriverAgent-brdadhpuduowllgivnnvuygpwhzy/Build/Products/Debug-iphoneos/IntegrationApp.app");

		capabilities.setCapability("udid", "571e1c5acf8c4e0d47c6d146186d8749c8fab5b0");

		capabilities.setCapability("bundleId", "com.facebook.wda.integrationApp");

		capabilities.setCapability("automationName", "XCUITest");

		driver = new IOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		driver.findElement(MobileBy.AccessibilityId("Attributes")).click();

		driver.findElement(By.xpath("//XCUIElementTypeSlider")).sendKeys("0.2");
		driver.findElement(By.className("XCUIElementTypeSlider")).sendKeys("0.8");

		Thread.sleep(3000);

		driver.quit();

	}

}
