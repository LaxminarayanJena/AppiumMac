package iostest;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSStartScreenRecordingOptions;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.screenrecording.BaseStartScreenRecordingOptions;
import io.appium.java_client.screenrecording.ScreenRecordingUploadOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class TestTap {

	public static IOSDriver<IOSElement> driver;

	
	
	
	public static void tapByElement (WebElement element) {
        new TouchAction(driver)
                .tap(new TapOptions().withElement(ElementOption.element(element)))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(250))).perform();
    }
 
    //Tap by coordinates
    public static void tapByCoordinates (int x,  int y) {
        new TouchAction(driver)
                .tap(PointOption.point(x,y))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(250))).perform();
    }
 

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		// capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION, "1.6.4");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1.3");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone X");

		capabilities.setCapability("xcodeOrgId", "LUBWEAQUT4");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		capabilities.setCapability("app",
				"/Users/rahularora/Library/Developer/Xcode/DerivedData/WebDriverAgent-brdadhpuduowllgivnnvuygpwhzy/Build/Products/Debug-iphoneos/IntegrationApp.app");

		capabilities.setCapability("udid", "571e1c5acf8c4e0d47c6d146186d8749c8fab5b0");

		capabilities.setCapability("bundleId", "com.facebook.wda.integrationApp");

		capabilities.setCapability("automationName", "XCUITest");

		driver = new IOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		WebElement scroll = driver.findElement(MobileBy.AccessibilityId("Scrolling"));
		
		//tapByElement(scroll);
		tapByCoordinates(160,231);
		
		Thread.sleep(3000);

		driver.quit();

	}

}
